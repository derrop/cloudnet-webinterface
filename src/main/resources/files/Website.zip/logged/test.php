<?php

require '../mojang-api.class.php';
include '../config.php';
session_start(); 


   session_destroy();

